
# Infinity Landing Page

Landing Page | Infinity Squad. 

## Features

`Done ->`

- Project preset

`In Progress`

- Figma Design


## Authors

- [@ViniciusCuest](https://github.com/ViniciusCuest)
- [@Elias](https://github.com/EliasBRodrigues)
- [@João Jesus](https://github.com/jpfcordeiro)
- [@Kaio]

## License

[MIT](https://choosealicense.com/licenses/mit/)


## Tech Stack

**Front-end** `HTML`, `CSS`, `Javascript`

## 🛠 Skills
Html, Css, Javascript, Figma, Design Patterns, Pixel Perfect Git...

