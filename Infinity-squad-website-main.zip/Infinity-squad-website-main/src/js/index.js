let activeIndex = 0;

let darkIcon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M144.7 98.7c-21 34.1-33.1 74.3-33.1 117.3c0 98 62.8 181.4 150.4 211.7c-12.4 2.8-25.3 4.3-38.6 4.3C126.6 432 48 353.3 48 256c0-68.9 39.4-128.4 96.8-157.3zm62.1-66C91.1 41.2 0 137.9 0 256C0 379.7 100 480 223.5 480c47.8 0 92-15 128.4-40.6c1.9-1.3 3.7-2.7 5.5-4c4.8-3.6 9.4-7.4 13.9-11.4c2.7-2.4 5.3-4.8 7.9-7.3c5-4.9 6.3-12.5 3.1-18.7s-10.1-9.7-17-8.5c-3.7 .6-7.4 1.2-11.1 1.6c-5 .5-10.1 .9-15.3 1c-1.2 0-2.5 0-3.7 0c-.1 0-.2 0-.3 0c-96.8-.2-175.2-78.9-175.2-176c0-54.8 24.9-103.7 64.1-136c1-.9 2.1-1.7 3.2-2.6c4-3.2 8.2-6.2 12.5-9c3.1-2 6.3-4 9.6-5.8c6.1-3.5 9.2-10.5 7.7-17.3s-7.3-11.9-14.3-12.5c-3.6-.3-7.1-.5-10.7-.6c-2.7-.1-5.5-.1-8.2-.1c-3.3 0-6.5 .1-9.8 .2c-2.3 .1-4.6 .2-6.9 .4z"/></svg>';

let lightIcon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M297.2 248.9C311.6 228.3 320 203.2 320 176c0-70.7-57.3-128-128-128S64 105.3 64 176c0 27.2 8.4 52.3 22.8 72.9c3.7 5.3 8.1 11.3 12.8 17.7l0 0c12.9 17.7 28.3 38.9 39.8 59.8c10.4 19 15.7 38.8 18.3 57.5H109c-2.2-12-5.9-23.7-11.8-34.5c-9.9-18-22.2-34.9-34.5-51.8l0 0 0 0c-5.2-7.1-10.4-14.2-15.4-21.4C27.6 247.9 16 213.3 16 176C16 78.8 94.8 0 192 0s176 78.8 176 176c0 37.3-11.6 71.9-31.4 100.3c-5 7.2-10.2 14.3-15.4 21.4l0 0 0 0c-12.3 16.8-24.6 33.7-34.5 51.8c-5.9 10.8-9.6 22.5-11.8 34.5H226.4c2.6-18.7 7.9-38.6 18.3-57.5c11.5-20.9 26.9-42.1 39.8-59.8l0 0 0 0 0 0c4.7-6.4 9-12.4 12.7-17.7zM192 128c-26.5 0-48 21.5-48 48c0 8.8-7.2 16-16 16s-16-7.2-16-16c0-44.2 35.8-80 80-80c8.8 0 16 7.2 16 16s-7.2 16-16 16zm0 384c-44.2 0-80-35.8-80-80V416H272v16c0 44.2-35.8 80-80 80z"/></svg>';

const html = document.getElementById("html");
const icon = document.getElementById("icon-mode");


const header = document.getElementById("header");
const mode = document.getElementById("mode");
const body = document.getElementById("body");
const list = document.getElementById("list");

const mainQtt = document.querySelectorAll("main").length;

let sections = body.clientHeight / +mainQtt;

window.onload = () => {
   const localSavedTheme = localStorage.getItem("mode");
   if (localSavedTheme === "dark") {
      mode.innerHTML = lightIcon; 
      html.classList.add("dark");
   } else {
      mode.innerHTML = darkIcon;
   }
}

body.onresize = () => {
   sections = body.clientHeight / 4;
}

body.onscroll = (evt) => {
   const currentScroll = evt.currentTarget.scrollY;

   for (let i = 0; i <= mainQtt; i++) {
      if (currentScroll >= (sections * i) - 30 && currentScroll < (sections * (i + 1))) {
         activeHeaderNavIndicator(activeIndex, i);
         activeIndex = i;
      }
   }

   if (currentScroll > 150) {
      header.classList.add("active");
      return;
   }
   header.classList.remove("active");
}

function changeIndex(e) {
   e.preventDefault();
   const index = e.target.attributes.id.value;

   if (activeIndex != index) {
      html.scroll({
         top: sections * index,
         behavior: 'smooth'
      });
   }
   activeIndex = index;
}

function activeHeaderNavIndicator(lastId, newId) {
   document.getElementById(lastId).removeAttribute("class");
   document.getElementById(newId).classList.add("active");
}

function iconAnimation(theme) {

   mode.removeChild(mode.firstElementChild);   
   if (theme === 'light_mode') {
      localStorage.setItem("mode", "dark");
      mode.innerHTML = darkIcon;
      html.classList.add("dark");
   } else {
      mode.innerHTML = lightIcon;
      html.classList.remove("dark");
      localStorage.clear();
   }
}

mode.addEventListener("click", () => {
   const savedMode = localStorage.getItem("mode");
   savedMode ? iconAnimation('dark_mode') : iconAnimation('light_mode');
});   